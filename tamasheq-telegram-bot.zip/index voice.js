const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const fs = require("fs");
require("dotenv").config();
const exp = "Here's an example \n arabic: اخرج من ذلك المكان \n tamasheq: ازجر دغ أدج وديد";
const { TOKEN } = process.env;

console.log(TOKEN);
const bot = new TelegramBot(TOKEN, { polling: true });

bot.on("message", async(msg) => {

    console.log(msg);
    console.table({ message: msg.text })
    const chatId = msg.chat.id;
    const userInput = msg.text;
    if (userInput != "/start") return;
    bot.sendMessage(chatId, "Would you like to help us collecting Tamasheq data?", {
        "reply_markup": {
            "inline_keyboard": [
                [{
                    text: "Yes",
                    callback_data: "yes",
                }, {
                    text: "No",
                    callback_data: "no",
                }]
            ]
        }
    });
});




// Handle callback queries 
bot.on('callback_query', async function onCallbackQuery(callbackQuery) {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const opts = {
        chat_id: msg.chat.id,
        // message_id: msg.message_id,
    };

    if (action === 'yes') {
        // text = 'jri';
        bot.deleteMessage(chatId, msg.message_id);
        yes_handle(chatId)
    } else if (action === 'no') {
        // text = 'ma tjrich';
        bot.deleteMessage(chatId, msg.message_id)
    } else if (action === 'accept') {
        // text = 'acceptinsd';
        bot.deleteMessage(chatId, msg.message_id)
        accept_handle(chatId);


    }

});

const yes_handle = async(chatId) => {
    bot.sendMessage(chatId, exp, {
        "reply_markup": {
            "inline_keyboard": [
                [{
                    text: "accept",
                    callback_data: "accept",
                }, {
                    text: "Cancel",
                    callback_data: "no",
                }]
            ]
        }
    });
}

const no_handle = async(chatId) => {
    bot.sendMessage(chatId, "Thank you for your help.\nIf you would like to start again, type /start", {
        "reply_markup": {
            "inline_keyboard": [
                [{
                    text: "accept",
                    callback_data: "accept",
                }, {
                    text: "Cancel",
                    callback_data: "no",
                }]
            ]
        }
    });
}

const accept_handle = async(chatId) => {
    // create the voices folder if it doesn't exist
    if (!fs.existsSync("voices")) {
        fs.mkdirSync("voices");
    }

    // read the file containing Tamasheq sentences
    await fs.readFile("tamasheq.txt", "utf8", async(err, data) => {
        if (err) {
            console.error(err);
            return;
        }

        // split the sentences by newline
        const sentences = data.split("\n");


        // pick the first sentence
        const sentence_nbr = Number(sentences[0]);
        const sentence = sentences[sentence_nbr].split("\t")[1];

        if (!sentence) {
            await bot.sendMessage(chatId, `Thank you we appreciate your support, we are all cough up!!`);
            return;

        }
        // send the sentence to the chat
        await bot.sendMessage(chatId, `Send a voice reading this sentence:\n ${sentence}`);

        // wait for the client's voice message
        await bot.once("voice", async(msg) => {

            //create folder if does not exist
            if (!fs.existsSync(`voices/${sentence_nbr+1}`)) {
                fs.mkdirSync(`voices/${sentence_nbr+1}`);
            }
            // save the voice message to a file
            await bot.downloadFile(msg.voice.file_id, `voices/${sentence_nbr+1}`);

            //update tamasheq.txt
            sentences[0] = sentence_nbr + 1;
            await fs.writeFile("tamasheq.txt", sentences.join("\n"), (err) => {
                if (err) console.error(err);
            });

            // ask the client if they want to continue
            await bot.sendMessage(chatId, "Would you like to continue?", {
                "reply_markup": {
                    "inline_keyboard": [
                        [{
                            text: "Yes",
                            callback_data: "accept",
                        }, {
                            text: "No",
                            callback_data: "no",
                        }]
                    ]
                }
            });
        });
    });
};